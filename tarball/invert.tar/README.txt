'./test-docs' contains the set of documents used in the paper.
To compile, just make.
Then, to run with the test documents: './invert ./test-docs'
It will prompt for searches and return the ranked list of documents.

The indexes are written to 'indexes.log' as JSON for verification.

Let me know if you need anything else for testing!

- Finley
